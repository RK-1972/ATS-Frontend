import API from "../api/axios";

const RAISE_REQUISITION_CODE = "RAISE_REQUISITION";

function getLoggedInUser() {
  try {
    return JSON.parse(localStorage.getItem("user") || "null");
  } catch {
    return null;
  }
}

function isRaiseRequisitionEnabled(permissions) {
  if (!Array.isArray(permissions) || permissions.length === 0) {
    return false;
  }

  const permission = permissions.find(
    (row) =>
      String(row.permission_code || "").trim().toUpperCase() ===
      RAISE_REQUISITION_CODE
  );

  return Boolean(permission?.is_enabled);
}

/**
 * Returns whether the logged-in user may raise requisitions.
 * Admins are always allowed; others require RAISE_REQUISITION from user permissions.
 */
async function canRaiseRequisition() {
  const user = getLoggedInUser();

  if (!user) {
    return false;
  }

  if (user.role_name === "Admin") {
    return true;
  }

  const employeeCode = user.employee_code;

  if (!employeeCode) {
    return false;
  }

  try {
    const response = await API.get(
      `/user-permissions/${encodeURIComponent(employeeCode)}`
    );
    const permissions = response.data?.data || [];

    return isRaiseRequisitionEnabled(permissions);
  } catch {
    return false;
  }
}

const AuthorizationService = {
  canRaiseRequisition
};

export { canRaiseRequisition };
export default AuthorizationService;
