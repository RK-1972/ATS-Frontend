/**
 * Canonical requisition req_status values already used in production paths.
 * Do not add new lifecycle statuses here until the status engine is introduced.
 */

export const REQUISITION_STATUS = {
  OPEN: "Open",
  PENDING_TA_LEAD: "Pending TA Lead",
  APPROVED: "Approved"
};

export default REQUISITION_STATUS;
